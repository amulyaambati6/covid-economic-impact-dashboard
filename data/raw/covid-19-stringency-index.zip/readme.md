# COVID-19: Stringency Index - Data package

This data package contains the data that powers the chart ["COVID-19: Stringency Index"](https://ourworldindata.org/explorers/covid?Metric=Stringency+Index&Interval=Daily&Relative+to+population=false&country=USA~BRA~JPN~DEU) on the Our World in Data website.

### Active Filters

A filtered subset of the full data was downloaded. The following filters were applied:

## CSV structure

Each row is an observation for an entity (usually a country or region) at a timepoint.

- "Entity" — the name of the entity, e.g. "United States".
- "Code" — our internal entity code. For most countries this is the [ISO alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code, e.g. "USA"; historical and other non-standard entities get a custom code.
- "Year" or "Day" — the timepoint. Annual data has a "Year" column holding an integer year; otherwise a "Day" column holds a date string in the form "YYYY-MM-DD".
- Every remaining column is a data column, each one a time series. Downloaded with the "full data" option each corresponds to one time series below; with "only selected data visible in the chart" they are transformed depending on the chart type, so the correspondence may be less direct.


## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc.

## How we process data at Our World in Data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stitch together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

Preparing this data involves several processing steps. Depending on the data, this can include standardizing country names and world region definitions, converting units, calculating derived indicators such as per capita measures, as well as adding or adapting metadata such as the name or the description given to an indicator.
[Read about our data pipeline](https://docs.owid.io/projects/etl/).

## Detailed information about each time series


### Non-vaccinated
Aggregate index that gives an overall impression of government activity. Takes only 'containment and closure policies'-indicators into account. It constructs the index using 'non-vaccinated' (NV) policies if present, or otherwise using 'everyone' (E) policies.
Last updated: August 1, 2024  
Source: Blavatnik School of Government, University of Oxford (2023) – with minor processing by Our World in Data  

#### How to cite this data

Blavatnik School of Government, University of Oxford (2023) – with minor processing by Our World in Data

#### What you should know about this data
Estimated as the weighted average for most jurisdictions (but for which we substitute the simple average for jurisdictions where it is not possible to calculate the weighted average.


### Vaccinated
Aggregate index that gives an overall impression of government activity. Takes only 'containment and closure policies'-indicators into account. It constructs the index using 'vaccinated' (V) policies if present, or otherwise using 'everyone' (E) policies.
Last updated: August 1, 2024  
Source: Blavatnik School of Government, University of Oxford (2023) – with minor processing by Our World in Data  

#### How to cite this data

Blavatnik School of Government, University of Oxford (2023) – with minor processing by Our World in Data

#### What you should know about this data
Estimated as the weighted average for most jurisdictions (but for which we substitute the simple average for jurisdictions where it is not possible to calculate the weighted average.


### Weighted average of vaccinated and non-vaccinated
Aggregate index that gives an overall impression of government activity. Takes only 'containment and closure policies'-indicators into account. It takes an average of the "_Nonvax" and "_Vax" indices weighted by the proportion of the population that is vaccinated.
Last updated: August 1, 2024  
Source: Blavatnik School of Government, University of Oxford (2023) – with minor processing by Our World in Data  

#### How to cite this data

Blavatnik School of Government, University of Oxford (2023) – with minor processing by Our World in Data

#### What you should know about this data
Estimated as the weighted average for most jurisdictions (but for which we substitute the simple average for jurisdictions where it is not possible to calculate the weighted average.


## Sources

These are the sources behind the data in this package. Each time series above names the ones it draws on in its citation.

### Blavatnik School of Government, University of Oxford – Government Response Tracker (OxCGRT)

The Oxford Covid-19 Government Response Tracker (OxCGRT) collected information on which pandemic response measures were enacted by governments, and when. During the pandemic this helped decision-makers and citizens understand governmental responses in a consistent way, aiding efforts to fight the pandemic. Now that covid-19 is no longer designated a public health emergency of international concern, the data can be used for research purposes and to prepare for future pandemics.

The OxCGRT systematically collected information on several different common policy responses governments took over 2020, 2021, and 2022, recorded these policies on a scale to reflect the extent of government action, and aggregates these scores into a suite of policy indices. We also collected differentiated policies data where different policies apply to people who were vaccinated and non-vaccinated.

The OxCGRT reports publicly available information on 24 policy indicators and a miscellaneous notes field of government response organized into four groups:

- C: containment and closure policies
- E: economic policies
- H: health system policies
- V: vaccination policies

To help make sense of the data, we have produced four indices that aggregate the data into a single number. For more details about how the indices are comprised, see the section 'Calculation of policy indices' in our documentation. Each of these indices reports a number between 0 to 100 that reflects the level of the government's response along certain dimensions:

- overall government response index (all indicators)
- containment and health index (all C and H indicators)
- stringency index (all C indicators, plus H1 which records public information campaigns)
- economic support index (all E indicators)

These indices are a measure of how many of the relevant policy types a government has acted upon, and to what degree. The index cannot say whether a government's policy has been implemented effectively.

Because of the complexity of the dataset, it is published across 27 CSV files. Our technical documentation (https://github.com/OxCGRT/covid-policy-dataset/blob/main/documentation_and_codebook.md) contains all the information users need to navigate and use the data.

Producer: Blavatnik School of Government, University of Oxford  
Published: 2023-06-21  
Retrieved on: 2024-08-01  
Retrieved from: https://github.com/OxCGRT/covid-policy-dataset  
Direct download: https://github.com/OxCGRT/covid-policy-dataset/raw/main/data/OxCGRT_fullwithnotes_national_2020_v1.csv  
License: CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/)  

Citation: Thomas Hale, Noam Angrist, Rafael Goldszmidt, Beatriz Kira, Anna Petherick, Toby Phillips, Samuel Webster, Emily Cameron-Blake, Laura Hallas, Saptarshi Majumdar, and Helen Tatlow. (2021). “A global panel database of pandemic policies (Oxford COVID-19 Government Response Tracker).” Nature Human Behaviour. https://doi.org/10.1038/s41562-021-01079-8

    